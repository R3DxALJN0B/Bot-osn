# config.py - dummy content
